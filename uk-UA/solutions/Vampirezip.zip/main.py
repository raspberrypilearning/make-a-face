#!/bin/python3

from processing import *

def setup():
  size(400, 400)
  noStroke()
  

def draw():
  background(255)
  purple = color(184, 178, 201)
  brown = color(200, 120, 0)
  green = color(100, 155, 0)
  
  # Hair and face
  fill(0)
  ellipse(200, 200, 200, 190)
  fill(purple)
  ellipse(200, 240, 180, 110)
  ellipse(150, 210, 100, 140)
  ellipse(250, 210, 100, 140)
  fill(0)
  
  # Eyes
  ellipse(160, 220, 30, 30)
  ellipse(240, 220, 30, 30)
  fill(255)
  ellipse(165, 215, 10, 10)
  ellipse(245, 215, 10, 10)
  fill(purple)
  ellipse(160, 240, 30, 30)
  ellipse(240, 240, 30, 30)
  
  # Mouth
  fill(0)
  rect(170, 260, 60, 5)
  fill(0)
  triangle(170, 260, 180, 280, 190, 260)
  triangle(210, 260, 220, 280, 230, 260)
run()