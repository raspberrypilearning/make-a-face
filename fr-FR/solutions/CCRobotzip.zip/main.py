#!/bin/python3

from processing import *

def setup():
  size(400, 400)
  stroke(0)
  strokeWeight(4)

def draw():
  background(255)
  orange = color(255, 165, 0)
  brown = color(200, 120, 0)
  green = color(100, 155, 0)
  fill(149, 149, 149)
  rect(100, 150, 200, 200)
  fill(0)
  
  # Eyes
  fill(0, 194, 183)
  rect(135, 150, 50, 90)
  rect(215, 150, 50, 90)
  fill(0)
  ellipse(160, 220, 30, 30)
  ellipse(240, 220, 30, 30)

  
  # Mouth
  fill(90, 110, 184)
  red = 90
  green = 110
  blue = 180
  gap = 0
  for i in range (0,6):
    rect(100+gap, 300, 33, 50)
    gap = gap+33
    fill(red, green, blue)
    red = red+40
    blue = blue-30
  
run()